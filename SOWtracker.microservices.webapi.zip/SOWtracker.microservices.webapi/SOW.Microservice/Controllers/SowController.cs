﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SOW.Microservice.Data;
using SOW.Microservice.Models;

namespace SOW.Microservice.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SowController : ControllerBase
    {
        private readonly SowDbContext _context;

        public SowController(SowDbContext context)
        {
            _context = context;
        }

        // GET: api/Sow
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Sow>>> GetSows()
        {
          if (_context.Sows == null)
          {
              return NotFound();
          }
            return await _context.Sows.ToListAsync();
        }

        // GET: api/Sow/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Sow>> GetSow(int id)
        {
          if (_context.Sows == null)
          {
              return NotFound();
          }
            var sow = await _context.Sows.FindAsync(id);

            if (sow == null)
            {
                return NotFound();
            }

            return sow;
        }

        // PUT: api/Sow/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutSow(int id, Sow sow)
        {
            if (id != sow.SowId)
            {
                return BadRequest();
            }

            _context.Entry(sow).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!SowExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/Sow
        [HttpPost]
        public async Task<ActionResult<Sow>> PostSow(Sow sow)
        {
          if (_context.Sows == null)
          {
              return Problem("Entity set 'SowDbContext.Sows'  is null.");
          }
            _context.Sows.Add(sow);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetSow", new { id = sow.SowId }, sow);
        }

        // DELETE: api/Sow/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteSow(int id)
        {
            if (_context.Sows == null)
            {
                return NotFound();
            }
            var sow = await _context.Sows.FindAsync(id);
            if (sow == null)
            {
                return NotFound();
            }

            _context.Sows.Remove(sow);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool SowExists(int id)
        {
            return (_context.Sows?.Any(e => e.SowId == id)).GetValueOrDefault();
        }
    }
}
