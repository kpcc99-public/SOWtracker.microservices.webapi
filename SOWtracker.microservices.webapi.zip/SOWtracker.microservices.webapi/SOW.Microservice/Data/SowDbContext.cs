﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using SOW.Microservice.Models;

namespace SOW.Microservice.Data;

public partial class SowDbContext : DbContext
{
    public SowDbContext()
    {
    }

    public SowDbContext(DbContextOptions<SowDbContext> options): base(options)
    {
    }

    public virtual DbSet<Sow> Sows { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Sow>(entity =>
        {
            entity.ToTable("SOW");

            entity.Property(e => e.AccountManager).HasMaxLength(200);
            entity.Property(e => e.Band).HasMaxLength(100);
            entity.Property(e => e.ExternalResource).HasMaxLength(100);
            entity.Property(e => e.InternalResource).HasMaxLength(100);
            entity.Property(e => e.IsDeleted).HasColumnName("isDeleted");
            entity.Property(e => e.Jrcode).HasMaxLength(10).HasColumnName("JRCode");
            entity.Property(e => e.ProjectId).HasMaxLength(100);
            entity.Property(e => e.RequestCreationDate).HasColumnType("datetime");
            entity.Property(e => e.Role).HasMaxLength(100);
            entity.Property(e => e.SoName).HasMaxLength(100);
            entity.Property(e => e.Ustpocid).HasColumnName("USTPOCId");
            entity.Property(e => e.Usttpmid).HasColumnName("USTTPMId");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
