﻿using System;
using System.Collections.Generic;

namespace SOW.Microservice.Models;

public partial class Sow
{
    public int SowId { get; set; }

    public string? SoName { get; set; }

    public string? Jrcode { get; set; }

    public DateTime? RequestCreationDate { get; set; }

    public int AccountId { get; set; }

    public int TechnologyId { get; set; }

    public string? Role { get; set; }

    public int? LocationId { get; set; }

    public int RegionId { get; set; }

    public int? TargetOpenPositions { get; set; }

    public int? PositionsTobeClosed { get; set; }

    public int Ustpocid { get; set; }

    public int RecruiterId { get; set; }

    public int Usttpmid { get; set; }

    public int DellManagerId { get; set; }

    public int? StatusId { get; set; }

    public string? Band { get; set; }

    public string? ProjectId { get; set; }

    public string? AccountManager { get; set; }

    public string? ExternalResource { get; set; }

    public string? InternalResource { get; set; }

    public bool IsDeleted { get; set; }
}
