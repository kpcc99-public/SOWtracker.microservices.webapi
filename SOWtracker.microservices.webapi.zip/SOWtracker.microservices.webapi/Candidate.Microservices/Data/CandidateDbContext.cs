﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using Candidate.Microservices.Models;

namespace Candidate.Microservices.Data;

public partial class CandidateDbContext : DbContext
{
    public CandidateDbContext()
    {
    }

    public CandidateDbContext(DbContextOptions<CandidateDbContext> options): base(options)
    {
    }

    public virtual DbSet<Candidate.Microservices.Models.Candidate> Candidates { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        => optionsBuilder.UseSqlServer("");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Candidate.Microservices.Models.Candidate>(entity =>
        {
            entity.HasKey(e => e.CandidateId).HasName("PK__Candidate");

            entity.ToTable("Candidate");

            entity.Property(e => e.CandidateName).HasMaxLength(100);
            entity.Property(e => e.Dob).HasColumnType("datetime").HasColumnName("DOB");
            entity.Property(e => e.EmailId).HasMaxLength(100);
            entity.Property(e => e.Gender).HasMaxLength(20);
            entity.Property(e => e.IsDeleted).HasColumnName("isDeleted");
            entity.Property(e => e.JoiningDate).HasColumnType("datetime");
            entity.Property(e => e.Location).HasMaxLength(100);
            entity.Property(e => e.MobileNo).HasMaxLength(50);
            entity.Property(e => e.Pincode).HasMaxLength(10);
            entity.Property(e => e.Status).HasMaxLength(50);
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
