﻿using System;
using System.Collections.Generic;

namespace Candidate.Microservices.Models;

public partial class Candidate
{
    public int CandidateId { get; set; }

    public string CandidateName { get; set; } = null!;

    public string MobileNo { get; set; } = null!;

    public string Gender { get; set; } = null!;

    public DateTime Dob { get; set; }

    public string EmailId { get; set; } = null!;

    public string? Skills { get; set; }

    public string Location { get; set; } = null!;

    public string Pincode { get; set; } = null!;

    public string Address { get; set; } = null!;

    public DateTime JoiningDate { get; set; }

    public string Status { get; set; } = null!;

    public bool IsInternal { get; set; }

    public bool IsDeleted { get; set; }
}
